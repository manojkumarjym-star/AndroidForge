package com.example.rupeewise;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int SMS_PERMISSION_REQUEST = 42;
    private boolean pendingImport = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8,15,28));
        getWindow().setNavigationBarColor(Color.rgb(8,15,28));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11,18,32));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        webView.addJavascriptInterface(new SmsBridge(), "AndroidSms");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean hasSmsPermission() {
        return checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED;
    }
    private void requestSmsAccess() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS}, SMS_PERMISSION_REQUEST);
        }
    }

    private class SmsBridge {
        @JavascriptInterface public String getPendingSms() {
            String pending = getSharedPreferences("sms_queue", MODE_PRIVATE).getString("pending", "[]");
            getSharedPreferences("sms_queue", MODE_PRIVATE).edit().putString("pending", "[]").apply();
            return pending;
        }
        @JavascriptInterface public void importInbox() {
            runOnUiThread(() -> {
                if (!hasSmsPermission()) { pendingImport = true; requestSmsAccess(); }
                else importInboxNow();
            });
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == SMS_PERMISSION_REQUEST) {
            boolean granted = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
            if (granted && pendingImport) importInboxNow();
            else Toast.makeText(this, "SMS permission not granted; SMS import is unavailable.", Toast.LENGTH_LONG).show();
            pendingImport = false;
        }
    }

    private void importInboxNow() {
        JSONArray messages = new JSONArray();
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(Uri.parse("content://sms/inbox"), new String[]{"body", "date", "address"}, null, null, "date DESC");
            if (cursor != null) {
                int max = 5000, count = 0;
                while (cursor.moveToNext() && count++ < max) {
                    JSONObject obj = new JSONObject();
                    obj.put("body", cursor.getString(0) == null ? "" : cursor.getString(0));
                    obj.put("date", cursor.getLong(1));
                    obj.put("sender", cursor.getString(2) == null ? "" : cursor.getString(2));
                    messages.put(obj);
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "Could not read SMS inbox on this device.", Toast.LENGTH_LONG).show();
        } finally { if (cursor != null) cursor.close(); }
        final String payload = messages.toString();
        webView.post(() -> webView.evaluateJavascript("receiveSmsBatch(" + JSONObject.quote(payload) + ")", null));
    }

    @Override public void onBackPressed() {
        webView.evaluateJavascript("(function(){var a=document.querySelector('.screen.active');if(a&&a.id!=='home'){showScreen('home');return 'handled'}return 'exit'})()", value -> {
            if (value == null || value.contains("exit")) MainActivity.super.onBackPressed();
        });
    }
}

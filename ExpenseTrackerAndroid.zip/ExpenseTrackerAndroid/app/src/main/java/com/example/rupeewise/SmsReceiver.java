package com.example.rupeewise;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsMessage;
import android.os.Bundle;
import org.json.JSONArray;
import org.json.JSONObject;

public class SmsReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!"android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction())) return;
        try {
            Bundle bundle = intent.getExtras();
            if (bundle == null) return;
            Object[] pdus = (Object[]) bundle.get("pdus");
            if (pdus == null) return;
            String format = bundle.getString("format");
            JSONArray queue;
            String saved = context.getSharedPreferences("sms_queue", Context.MODE_PRIVATE).getString("pending", "[]");
            try { queue = new JSONArray(saved); } catch (Exception e) { queue = new JSONArray(); }
            for (Object pdu : pdus) {
                SmsMessage sms = SmsMessage.createFromPdu((byte[]) pdu, format);
                JSONObject m = new JSONObject();
                m.put("body", sms.getMessageBody() == null ? "" : sms.getMessageBody());
                m.put("date", sms.getTimestampMillis());
                m.put("sender", sms.getOriginatingAddress() == null ? "" : sms.getOriginatingAddress());
                queue.put(m);
            }
            context.getSharedPreferences("sms_queue", Context.MODE_PRIVATE).edit().putString("pending", queue.toString()).apply();
        } catch (Exception ignored) { }
    }
}

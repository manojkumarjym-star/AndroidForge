# RupeeWise — Android Expense Tracker

Features:
- Income and expenses in INR
- Category-wise donut/pie chart and percentages
- Today / week / month breakdowns
- Monthly summary and last-7-days spending chart
- Searchable transaction history; edit/delete
- Total and category monthly budgets
- Local-only storage; CSV export and JSON backup/restore

## Build an APK
1. Install Android Studio on a Windows, macOS, or Linux computer.
2. Open this project folder (`ExpenseTrackerAndroid`) in Android Studio.
3. Let Gradle sync. Use JDK 17 if Android Studio asks for a Gradle JDK.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy it to your Android phone and open it. Allow installing unknown apps for the app you use to open it, if prompted.

This project uses an Android WebView to run the self-contained UI in `app/src/main/assets/index.html`. No internet permission or remote services are needed. Data is saved in WebView local storage on the phone; export a JSON backup before clearing app data or uninstalling.

## Note
The included app is a starter implementation. Test backup/restore and the transaction flows before relying on it for financial records. For release distribution, generate a signed APK from Android Studio.

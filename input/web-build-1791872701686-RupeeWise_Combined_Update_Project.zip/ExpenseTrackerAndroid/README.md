# RupeeWise Android project (combined update)

This project contains the combined RupeeWise prototype: dark theme, transaction history and budgets, SMS review inbox with editable category/amount/date/payment method, people management, equal/unequal/percentage split calculator, credit-card balances and repayment entries, loan balances and repayment entries, and custom trackers/categories. Data is stored locally in WebView localStorage.

## Build using AndroidForge from an Android phone
1. Back up/export JSON from the currently installed RupeeWise first.
2. Upload this complete `ExpenseTrackerAndroid` project to your AndroidForge repository/build workflow. Keep `applicationId` `com.example.rupeewise` and the same signing key as your installed APK if you want Android to install it as an update.
3. Run the AndroidForge build workflow and download the APK artifact to your phone.
4. Install only if the signature/package matches. If Android reports a signature conflict, do not uninstall the old app until you have exported and verified a backup.
5. Open RupeeWise and choose Review → Import older SMS messages. Grant SMS permission only if you want SMS import. Check every result; detections remain pending until you approve them.

## SMS privacy / limitations
- SMS inbox import runs locally on the device after the user taps the import button and grants permission. It scans up to the latest 5,000 inbox messages. The parser is heuristic and can miss transactions or misread message formats; review each entry before approval.
- The included code requests READ_SMS and RECEIVE_SMS, but this prototype currently implements explicit inbox import, not a fully reliable background live-SMS receiver. Android and Google Play restrict SMS permissions; distribution through Google Play may not be permitted. Sideloading does not guarantee that every device/ROM will grant access.
- Before real-world use, test with non-sensitive/sample messages and verify your backup/restore. No SMS data is sent to a server by this code.

## Important
This is source code, not a prebuilt signed APK. Build/signing must be done by AndroidForge. Updating an installed app requires the same application ID and signing certificate. LocalStorage data may not survive uninstalling, clearing app data, changing WebView storage behavior, or changing app identity; export a backup first.
